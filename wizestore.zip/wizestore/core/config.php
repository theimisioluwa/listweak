<?php

define("GT3_IMGURL", get_template_directory_uri() . "/img");